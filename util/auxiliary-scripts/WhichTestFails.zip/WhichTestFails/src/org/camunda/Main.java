package org.camunda;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

    public static void main(String[] args) {
        ArrayList<String> numberOfOccurences = new ArrayList<>();
        /* Copy the results of the Jenkins execution and save it in the file below */
        String file = "/SOME_PATH/JenkinsDump.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String ID_PATTERN = "\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*";
                Pattern FQCN = Pattern.compile(ID_PATTERN + "(\\." + ID_PATTERN + ")*");
                int indexRunning = line.indexOf("[INFO] Running ");
                if (indexRunning >= 0)
                {
                    Matcher matcher = FQCN.matcher(line.substring(indexRunning + "[INFO] Running ".length()));
                    if(matcher.matches()) {
                        numberOfOccurences.add(matcher.group(1).replaceAll("\\.", ""));
                    }
                }
                // E.g. [2022-04-06T12:55:04.456Z] [INFO] Tests run: 21, Failures: 0, Errors: 0, Skipped: 0, Time
                // elapsed: 66.531 s - in org.camunda.optimize.service.compatibility.DmnCompatibilityIT
                int indexResult = line.indexOf("] Tests run: ");
                if(indexResult >= 0) {
                    indexResult = line.indexOf(" - in ");
                    Matcher matcher = FQCN.matcher(line.substring(indexResult + " - in ".length()));
                    if(matcher.matches()) {
                        String testClass = matcher.group(1).replaceAll("\\.", "");
                        if(numberOfOccurences.contains(testClass)) {
                            numberOfOccurences.remove(testClass);
                        } else {
                            System.out.println("Weird, class " + testClass + " has a result, but no start??");
                        }
                    }
                }
            }
        } catch (Exception e) {

        }
        for(String occurence : numberOfOccurences) {
            System.out.println("Test Class " + occurence + " did not finish!");
        }
    }
}
