# Infra team Helm chart for Preview Environments Ingresses

This is a Library Helm chart of the Infrastructure team that contains a helper with common Kubernetes Ingress annotations for Preview Environments.

**Warning: Published Helm chart contents will be publicly available!** (as an [OCI artifact](https://helm.sh/blog/storing-charts-in-oci/) at registry.camunda.cloud)

## How to release?

To release a new OCI Helm chart version, [draft a new Github Release](https://github.com/camunda/infra-preview-environments-ingress/releases/new) where the Git tag name (to be published) follows [Semantic Versioning](https://semver.org) (e.g. `1.3.0`). Use the auto-generated changelog that Github provides.

Find released Docker images [here](https://registry.camunda.cloud/harbor/projects/1/repositories/infra-preview-environments-ingress).

## Contributing
Before contributing, please make sure to activate `pre-commit` in this repository:
```shell
pre-commit install --install-hooks -t commit-msg -t pre-commit
```
