{{ define "infrapreviewenvironmentsingress.vouchUrl" }}{{ default "https://vouch.camunda.cloud" (.Values.ingress).vouchUrl }}{{ end }}

{{ define "infrapreviewenvironmentsingress.nginx.largeClientHeaderBuffersNumber" }}{{ default "4" (.Values.ingress).nginxLargeClientHeaderBuffersNumber }}{{ end }}
{{ define "infrapreviewenvironmentsingress.nginx.largeClientHeaderBuffersSize" }}{{ default "8k" (.Values.ingress).nginxLargeClientHeaderBuffersSize }}{{ end }}

{{ define "infrapreviewenvironmentsingress.argoUrl" }}{{ printf "https://argocd.int.camunda.com/applications/argocd/%s?view=network&resource=" .Release.Name }}{{ end }}

{{- define "infrapreviewenvironmentsingress.harborUrl" -}}
{{- if hasPrefix "optimize" .Release.Name }}
{{- printf "https://registry.camunda.cloud/harbor/projects/10/repositories/optimize/artifacts-tab" }}
{{- else if hasPrefix "operate" .Release.Name }}
{{- printf "https://registry.camunda.cloud/harbor/projects/11/repositories/camunda-operate/artifacts-tab" }}
{{- else if hasPrefix "identity" .Release.Name }}
{{- printf "https://registry.camunda.cloud/harbor/projects/25/repositories/identity/artifacts-tab" }}
{{- else if hasPrefix "web-modeler" .Release.Name }}
{{- printf "https://registry.camunda.cloud/harbor/projects/24/repositories" }}
{{- else if hasPrefix "cawemo" .Release.Name }}
{{- printf "https://registry.camunda.cloud/harbor/projects/16/repositories" }}
{{- else if hasPrefix "connectors" .Release.Name }}
{{- printf "https://registry.camunda.cloud/harbor/projects/33/repositories/connectors-bundle/artifacts-tab" }}
{{- else }}
{{- printf "https://registry.camunda.cloud/harbor/projects" }}
{{- end }}
{{- end }}

{{ define "infrapreviewenvironmentsingress.annotations" -}}
nginx.ingress.kubernetes.io/auth-response-headers: X-Vouch-User,X-Vouch-IdP-Claims-preferred_username
nginx.ingress.kubernetes.io/auth-signin: |-
  {{ include "infrapreviewenvironmentsingress.vouchUrl" $ }}/login?url=$scheme://$http_host$request_uri&vouch-failcount=$auth_resp_failcount&X-Vouch-Token=$auth_resp_jwt&error=$auth_resp_err
nginx.ingress.kubernetes.io/auth-snippet: |-
  auth_request_set $auth_resp_jwt $upstream_http_x_vouch_jwt;
  auth_request_set $auth_resp_err $upstream_http_x_vouch_err;
  auth_request_set $auth_resp_failcount $upstream_http_x_vouch_failcount;
nginx.ingress.kubernetes.io/auth-url: "{{ include "infrapreviewenvironmentsingress.vouchUrl" $ }}/validate"
nginx.ingress.kubernetes.io/force-ssl-redirect: "true"
nginx.ingress.kubernetes.io/configuration-snippet: |
  recursive_error_pages on;
  error_page 400 = @error400;
  error_page 500 501 502 503 504 = @service_unavailable;
nginx.ingress.kubernetes.io/server-snippet: |-
  large_client_header_buffers {{ include "infrapreviewenvironmentsingress.nginx.largeClientHeaderBuffersNumber" $ }} {{ include "infrapreviewenvironmentsingress.nginx.largeClientHeaderBuffersSize" $ }};
  location @error400 { return 302 {{ include "infrapreviewenvironmentsingress.vouchUrl" $ }}/v1/logout; }
  location @service_unavailable {
    ssi on;
    return 503 '
      <!DOCTYPE html>
      <html lang=en-US>
      <head>
        <meta charset=utf-8>
        <base target="_blank">
        <title>Preview Environment not available</title>
        <meta name=viewport content="width=device-width, initial-scale=1">
        <style>
        body {
            font-family: IBM Plex Sans, sans-serif;
            text-align: center;
            padding: 50px;
        }

        h1 {
            color: #FC5D0D;
        }

        mark {
            background: #EEE;
            padding: 2px 4px;
            border: 1px solid #b4b4b4;
            border-radius: 3px;
        }

        p {
            color: #555;
        }

        .center-container {
            display: inline-block;
            text-align: left;
            padding: 0 10%;
        }

        #common-issues {
            display: flex;
            justify-content: center;
            padding: 0 10%;
        }

        #innerlist {
            padding: 0;
            text-align: left;
        }

        li {
            margin-bottom: 10px;
            list-style: none;
        }

        li:before {
            content: "\2022";
            display: inline-block;
            width: 1em;
            margin-left: -1em;
        }

        .margin {
            margin-top: 4px;
        }

        a {
            color: #0072CE;
        }
       </style>
      </head>
      <body>
          <h1>
           Your Preview Environment Is Currently Unavailable (Status Code: <!-- #echo var="status" -->)
          </h1>
          <p>
            <b>If you just deployed your <a href="https://confluence.camunda.com/display/HAN/Preview+Environments" class="link">Preview Environment</a> a few minutes ago, it is very likely this will auto-resolve within 15 minutes.
            <br>If it does not, here is how you can debug it.</b>
            <br>
            <div id="common-issues">
              <h3>Troubleshooting:</h3>
            </div>
            <div class="center-container">
             <ul id="innerlist">
                <li>
                    &#128011; Check that the Docker image of the application for the Preview Environment has been created and uploaded to <a href="{{ include "infrapreviewenvironmentsingress.harborUrl" $ }}" class="link">Harbor Docker Registry</a>.
                    <ul>
                        <li class="margin">How to log into Harbor: <a href="https://confluence.camunda.com/pages/viewpage.action?spaceKey=HAN&title=Harbor+Docker+Registry#HarborDockerRegistry-HowdoIandmyteamuseit?" class="link"> Guide</a>.</li>
                    </ul>
                 </li>
                <li>
                   &#9729; Your Preview Environment is deployed in the <a href="https://confluence.camunda.com/display/HAN/Infrastructure+Platform#InfrastructurePlatform-Clusters" class="link"> camunda-ci </a> Kubernetes cluster.
                   <ul>
                      <li>
                         You can check the logs of the corresponding Argo CD application, and of the application&apos;s Kubernetes pods: <a href="{{ include "infrapreviewenvironmentsingress.argoUrl" $ }}" class="link">ArgoCD</a>.
                         <ul class="margin">
                            <li>How to log into ArgoCD: click on the <mark>Log in via Okta</mark> button.</li>
                            <li>Make sure to check the application&apos;s pod logs to ensure the application is running successfully.</li>
                         </ul>
                      </li>
                      <li class="margin">
                         You can also check the logs of the application with <mark>kubectl</mark> directly.
                         <ul class="margin">
                            <li>How to get access to a Kubernetes cluster: <a href="https://confluence.camunda.com/display/HAN/Accessing+Kubernetes+Clusters" class="link">Guide </a> </li>
                            <li>How to see logs with <mark>kubectl</mark>: <a href="https://confluence.camunda.com/display/HAN/Useful+Kubernetes+Commands+and+Utilities" class="link">Guide</a> </li>
                         </ul>
                       </li>
                   </ul>
                <li> &#128221; Check the logs of the workflows in GitHub. The workflows for building and pushing the application Docker image to Harbor and to create a Preview Environment in ArgoCD should be passing. Try re-rerunning them if they failed. </li>
             </ul>
            </br></br>
            If none of these steps helped resolving the issue, feel free to ask a question in the
            <a href="https://camunda.slack.com/archives/C5AHF1D8T" class="link">#ask-infra</a> channel.
           </div>
          </p>
      </body>
      </html>';
  }
nginx.ingress.kubernetes.io/session-cookie-change-on-failure: "true"
nginx.ingress.kubernetes.io/session-cookie-conditional-samesite-none: "true"
{{ end }}
