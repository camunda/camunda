# Changelog

## 1.6.6 (2025-07-05)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v41.21.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/172


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.6.5...1.6.6

## 1.6.5 (2025-06-29)

## What's Changed
* ci: validate pr titles by @kellervater in https://github.com/camunda/infra-preview-environments-ingress/pull/168
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v41.15.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/170
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v41.16.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/171


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.6.4...1.6.5

## 1.6.4 (2025-06-21)

## What's Changed
* fix(deps): update dependency helm to v3.18.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/165
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v41 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/166


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.6.3...1.6.4

## 1.6.3 (2025-06-14)

## What's Changed
* chore(deps): update hashicorp/vault-action action to v3.4.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/161
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v40.54.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/162
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v40.55.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/164


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.6.2...1.6.3

## 1.6.2 (2025-06-07)

## What's Changed
* fix(deps): update dependency helm to v3.18.2 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/158
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v40.48.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/159


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.6.1...1.6.2

## 1.6.1 (2025-05-31)

## What's Changed
* fix(deps): update dependency helm to v3.18.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/155
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v40.36.8 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/156


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.6.0...1.6.1

## 1.6.0 (2025-05-28)

## What's Changed
* feat(deps): update dependency helm to v3.18.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/151


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.14...1.6.0

## 1.5.14 (2025-05-28)

## What's Changed
* chore(deps): update asdf-vm/actions action to v4 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/152


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.13...1.5.14

## 1.5.13 (2025-05-19)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v40.14.6 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/148


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.12...1.5.13

## 1.5.12 (2025-05-05)

## What's Changed
* chore(deps): update pre-commit hooks by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/145


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.11...1.5.12

## 1.5.11 (2025-04-26)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.258.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/142
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.259.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/144


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.10...1.5.11

## 1.5.10 (2025-04-19)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.251.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/140


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.9...1.5.10

## 1.5.9 (2025-04-12)

## What's Changed
* chore(deps): update actions/create-github-app-token action to v2 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/136
* fix(deps): update dependency helm to v3.17.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/139


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.8...1.5.9

## 1.5.8 (2025-04-05)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.227.2 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/135


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.7...1.5.8

## 1.5.7 (2025-03-29)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.220.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/133


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.6...1.5.7

## 1.5.6 (2025-03-22)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.205.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/131


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.5...1.5.6

## 1.5.5 (2025-03-15)

## What's Changed
* fix(deps): update dependency helm to v3.17.2 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/128
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.200.2 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/129


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.4...1.5.5

## 1.5.4 (2025-03-08)

## What's Changed
* chore(deps): update hashicorp/vault-action action to v3.3.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/125
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.185.9 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/126


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.3...1.5.4

## 1.5.3 (2025-03-01)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.182.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/123


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.2...1.5.3

## 1.5.2 (2025-02-22)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.174.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/121


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.1...1.5.2

## 1.5.1 (2025-02-15)

## What's Changed
* fix(deps): update dependency helm to v3.17.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/118
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.170.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/119


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.5.0...1.5.1

## 1.5.0 (2025-02-08)

## What's Changed
* feat(deps): update dependency helm to v3.17.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/110
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.164.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/117


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.13...1.5.0

## 1.4.13 (2025-02-02)

## What's Changed
* chore(deps): update pre-commit hooks by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/114


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.12...1.4.13

## 1.4.12 (2025-01-19)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.113.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/109
* chore(deps): update dependency actionlint to v1.7.7 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/112


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.11...1.4.12

## 1.4.11 (2025-01-11)

## What's Changed
* chore(deps): update dependency actionlint to v1.7.6 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/104
* chore(deps): update hashicorp/vault-action action to v3.1.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/106
* chore(deps): update pre-commit hooks by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/107


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.10...1.4.11

## 1.4.10 (2024-12-28)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.83.4 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/99
* chore(deps): update dependency actionlint to v1.7.5 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/102
* chore(deps): update pre-commit hooks by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/101


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.9...1.4.10

## 1.4.9 (2024-12-21)

## What's Changed
* fix(deps): update dependency helm to v3.16.4 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/95
* chore(deps): update pre-commit hooks by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/96
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.80.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/98


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.8...1.4.9

## 1.4.8 (2024-12-14)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.66.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/92
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.69.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/94


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.7...1.4.8

## 1.4.7 (2024-12-07)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.56.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/89
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.57.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/91


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.6...1.4.7

## 1.4.6 (2024-11-30)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.40.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/86
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.42.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/88


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.5...1.4.6

## 1.4.5 (2024-11-23)

## What's Changed
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.26.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/84


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.4...1.4.5

## 1.4.4 (2024-11-16)

## What's Changed
* chore(deps): update dependency helm to v3.16.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/80
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.17.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/81
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v39.18.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/83


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.3...1.4.4

## 1.4.3 (2024-11-09)

## What's Changed
* chore(deps): update dependency actionlint to v1.7.4 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/76
* chore(deps): update pre-commit hooks by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/78


**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.2...1.4.3

## 1.4.2 (2024-11-02)

## What's Changed
* chore(deps): update hashicorp/vault-action action to v2.8.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/53
* chore(deps): update dependency helm to v3.14.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/54
* chore(deps): update hashicorp/vault-action action to v3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/55
* chore(deps): update dependency helm to v3.14.2 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/56
* chore(deps): update dependency rhysd/actionlint to v1.6.27 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/57
* chore(deps): update dependency helm to v3.14.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/58
* chore(deps): update dependency helm to v3.14.4 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/59
* chore(deps): update dependency rhysd/actionlint to v1.7.0 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/60
* chore(deps): update dependency rhysd/actionlint to v1.7.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/62
* chore(deps): update dependency helm to v3.15.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/61
* chore(deps): update dependency helm to v3.15.2 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/64
* chore(deps): update dependency helm to v3.15.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/65
* chore(deps): update dependency helm to v3.15.4 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/66
* chore(deps): update dependency helm to v3.16.1 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/67
* chore(deps): update dependency actionlint to v1.7.2 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/68
* chore(deps): update dependency actionlint to v1.7.3 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/71
* chore(deps): update dependency helm to v3.16.2 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/72
* chore(deps): update dependency ubuntu to v24 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/70
* ci: Introduce Auto-Releases by @kellervater in https://github.com/camunda/infra-preview-environments-ingress/pull/73
* chore(deps): update pre-commit hook renovatebot/pre-commit-hooks to v38.142.2 by @renovate in https://github.com/camunda/infra-preview-environments-ingress/pull/75

## New Contributors
* @kellervater made their first contribution in https://github.com/camunda/infra-preview-environments-ingress/pull/73

**Full Changelog**: https://github.com/camunda/infra-preview-environments-ingress/compare/1.4.1...1.4.2
